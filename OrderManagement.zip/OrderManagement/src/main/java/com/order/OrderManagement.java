
package com.order;

import java.sql.*;
import java.util.Scanner;

public class OrderManagement {

    static final String URL = "jdbc:mysql://localhost:3306/ecommerce_db";
    static final String USER = "root";
    static final String PASSWORD = "123Roney@5";

    public static void main(String[] args) {

        try (Connection con = DriverManager.getConnection(URL, USER, PASSWORD);
             Scanner sc = new Scanner(System.in)) {

            System.out.println("MySQL Connected Successfully!");

            int choice;

            do {
                System.out.println("\n===== ORDER MANAGEMENT SYSTEM =====");
                System.out.println("1. Insert Three Orders");
                System.out.println("2. Search Orders by Status");
                System.out.println("3. Increase Order Quantity");
                System.out.println("4. Update Order Status");
                System.out.println("5. Calculate Total Order Value");
                System.out.println("6. Exit");

                System.out.print("Enter your choice: ");
                choice = sc.nextInt();
                sc.nextLine();

                switch (choice) {

                    case 1:
                        insertOrders(con);
                        break;

                    case 2:
                        searchOrders(con, sc);
                        break;

                    case 3:
                        increaseQuantity(con, sc);
                        break;

                    case 4:
                        updateStatus(con, sc);
                        break;

                    case 5:
                        calculateTotal(con);
                        break;

                    case 6:
                        System.out.println("Exiting Order Management System...");
                        break;

                    default:
                        System.out.println("Invalid choice!");
                }

            } while (choice != 6);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Q1 (a): Insert Three Orders
    static void insertOrders(Connection con) throws SQLException {

        String sql = "INSERT INTO Orders VALUES (?, ?, ?, ?, ?, ?)";

        try (PreparedStatement ps = con.prepareStatement(sql)) {

            insertOrder(ps, 107, "Rahul", "Laptop", 2, 55000, "Pending");
            insertOrder(ps, 108, "Aman", "Mobile", 3, 20000, "Shipped");
            insertOrder(ps, 109, "Priya", "Headphones", 4, 1500, "Delivered");
        }
    }

    static void insertOrder(PreparedStatement ps, int id,
            String customer, String product, int quantity,
            double price, String status) throws SQLException {

        try {
            ps.setInt(1, id);
            ps.setString(2, customer);
            ps.setString(3, product);
            ps.setInt(4, quantity);
            ps.setDouble(5, price);
            ps.setString(6, status);

            ps.executeUpdate();

            System.out.println("Order " + id + " inserted successfully!");

        } catch (SQLException e) {
            if (e.getErrorCode() == 1062) {
                System.out.println("Duplicate Order ID: " + id);
            } else {
                throw e;
            }
        }
    }

    // Q1 (b): Search Orders by Status
    static void searchOrders(Connection con, Scanner sc)
            throws SQLException {

        System.out.print("Enter order status: ");
        String status = sc.nextLine();

        String sql = "SELECT * FROM Orders WHERE status = ? " +
                     "AND quantity > 2 ORDER BY unit_price DESC";

        try (PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, status);

            try (ResultSet rs = ps.executeQuery()) {

                boolean found = false;

                while (rs.next()) {
                    found = true;

                    System.out.println("\nOrder ID: " + rs.getInt("order_id"));
                    System.out.println("Customer: " + rs.getString("customer_name"));
                    System.out.println("Product: " + rs.getString("product_name"));
                    System.out.println("Quantity: " + rs.getInt("quantity"));
                    System.out.println("Unit Price: " + rs.getDouble("unit_price"));
                    System.out.println("Status: " + rs.getString("status"));
                }

                if (!found) {
                    System.out.println("No matching orders found.");
                }
            }
        }
    }

    // Q1 (c): Increase Order Quantity
    static void increaseQuantity(Connection con, Scanner sc)
            throws SQLException {

        System.out.print("Enter Order ID: ");
        int id = sc.nextInt();

        System.out.print("Enter additional quantity: ");
        int quantity = sc.nextInt();
        sc.nextLine();

        if (quantity <= 0) {
            System.out.println("Quantity must be positive!");
            return;
        }

        String sql = "UPDATE Orders SET quantity = quantity + ? " +
                     "WHERE order_id = ?";

        try (PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, quantity);
            ps.setInt(2, id);

            int rows = ps.executeUpdate();

            if (rows > 0) {
                System.out.println("Order quantity updated successfully!");
            } else {
                System.out.println("Order ID not found!");
            }
        }
    }

    // Q1 (d): Update Order Status
    static void updateStatus(Connection con, Scanner sc)
            throws SQLException {

        System.out.print("Enter Order ID: ");
        int id = sc.nextInt();
        sc.nextLine();

        System.out.print("Enter new status: ");
        String status = sc.nextLine();

        String sql = "UPDATE Orders SET status = ? WHERE order_id = ?";

        try (PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, status);
            ps.setInt(2, id);

            int rows = ps.executeUpdate();

            if (rows > 0) {
                System.out.println("Order status updated successfully!");
            } else {
                System.out.println("Order ID not found!");
            }
        }
    }

    // Q1 (e): Calculate Total Order Value
    static void calculateTotal(Connection con) throws SQLException {

        String sql = "SELECT SUM(quantity * unit_price) AS total_value " +
                     "FROM Orders";

        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                System.out.println("Total Order Value: " +
                        rs.getDouble("total_value"));
            }
        }
    }
}
